const workInput = document.querySelector('#work-input');
const addWork = document.querySelector('#add-work');
const readingList = document.querySelector('#reading-list');
const workCount = document.querySelector('#work-count');
const edition = document.querySelector('#edition');
const cover = document.querySelector('#cover');
const minutes = document.querySelector('#minutes');
const pace = document.querySelector('#pace');
const minutesValue = document.querySelector('#minutes-value');
const paceValue = document.querySelector('#pace-value');
const timeBar = document.querySelector('#time-bar');
const pages = document.querySelectorAll('.page');
const planner = document.querySelector('#planner');
const check = document.querySelector('#check');
const status = document.querySelector('#status');

// Ide írd a megoldásodat! / Write your solution here!
